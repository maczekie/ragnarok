#!/bin/sh
zenity --question --title="Cervantes" --text="Are you sure you want to recompile your server? \n\n THIS CAN TAKE UPTO 5 MINUTES TO COMPLETE."
if [ $? = 0 ]; then
	cd /home/rathena/Desktop/rAthena
	xterm -title "Configure rAthena" -bg black -fg white -e ./configure
	xterm -title "Clean rAthena" -bg black -fg white -e make clean
	xterm -title "Compile rAthena" -bg black -fg white -hold -e "make server > /home/rathena/Desktop/compile.log" &
	zenity --info --title="Cervantes" --text="Your rAthena server is being recompiled. Check the console for any errors."
else
	exit
fi
