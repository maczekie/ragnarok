#!/bin/sh
CERV_DIR=/usr/share/cervantes
xterm -title "Change SSH Password" -bg black -fg white -hold -e sh $CERV_DIR/scripts/change_ssh_pass_script.sh &